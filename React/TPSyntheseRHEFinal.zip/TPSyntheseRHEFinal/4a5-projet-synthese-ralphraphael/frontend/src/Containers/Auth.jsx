import Login from "../components/login/Login";
export default function Auth() {
  return <Login />;
}
