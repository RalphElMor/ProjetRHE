import Signup from "../components/signup/Signup";
export default function Subscribe() {
  return <Signup />;
}
