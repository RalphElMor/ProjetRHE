const EQUIPES = [
  {
    id: "t1",
    nomEquipe: "Barcelone",
    imageUrl:
      "https://jetpunk.b-cdn.net/img/user-photo-library/24/245b108023-450.png",
    sport: "Soccer",
  },
  {
    id: "t1",
    nomEquipe: "Montreal",
    imageUrl:
      "https://jetpunk.b-cdn.net/img/user-photo-library/24/245b108023-450.png",
    sport: "Soccer",
  },
  {
    id: "t1",
    nomEquipe: "Espagne",
    imageUrl:
      "https://jetpunk.b-cdn.net/img/user-photo-library/24/245b108023-450.png",
    sport: "Soccer",
  },

  {
    id: "t1",
    nomEquipe: "Canada",
    imageUrl:
      "https://jetpunk.b-cdn.net/img/user-photo-library/24/245b108023-450.png",
    sport: "Baseball",
  },
];

export default EQUIPES;
